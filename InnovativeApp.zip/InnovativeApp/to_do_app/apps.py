from django.apps import AppConfig


class ToDoAppConfig(AppConfig):
    name = 'to_do_app'
